        //Q1
// let cities = ['Islamabad', 'Karachi', 'Lahore', 'Quatta', 'Hydrabad'];
// let a = cities.forEach(city =>{
//         console.log(city);
// })

    //  Q2
// let records = [
//     {rollNo: '0', name: 'Misbah', age: 20, qulification: 'intermediat'},
//     {rollNo: '1', name: 'Hibah', age: 16, qulification: 'Matric'},
//     {rollNo: '2', name: 'Ariba', age: 20, qulification: 'intermediat'},
//     {rollNo: '3', name: 'Uroosa', age: 21, qulification: 'BSC'},
//     {rollNo: '4', name: 'Hermain', age: 20, qulification: 'intermediat'}
// ];
// let a = records.forEach(rec => {
// console.log(rec);
// })

//    //Q3
// function array(Misbah, Hibah, Ariba, Uroosa, Hermain){
//     let arr = [1, 2, 3, 4, 5];
    
// }
// let arr = [1, 2, 3, 4, 5];
// let b = arr + array();
// console.log(b)

// it is not solve Q3

//    //Q4
// let records = [
//  firstName = ['Misbah', 'Hibah', 'Ariba', 'Uroosa', 'Hermain'],
//  lastName = ['Hingora', 'Sikander', 'Sikander', 'Bano', 'Zubiar']]
// let a = records.map(a => console.log(`${firstName[0]} ${lastName[0]} \n ${firstName[1]} ${lastName[1]} \n ${firstName[2]} ${lastName[2]} \n ${firstName[3]} ${lastName[3]} \n ${firstName[4]} ${lastName[4]}`))

       

//          //Q5
// let double = () => {
//    let p = +prompt('Enter number plz');
//    let b = p*2;
//    return b;
// }
// let a = double();
// console.log(a);


              //Q6
// let squre = () => {
//     let p = +prompt('Enter number plz');
//     let s = p*p;
//     return s
// };
// let a = squre();
// console.log(a);


//               //Q7
// var authentication = true;
// let allowed = new Promise((resolve, reject) =>{
// if(authentication == true){
//     resolve('u are allowed')
// }else{
//     reject('u are not allowed')
// }
// });
// allowed
// .then(res => console.log(res))
// .catch(err => console.log(err));


                    //Q8
// let age = 18;
// let canDrive = prompt('Can I drive my age is:');
// if(age <= canDrive){
//     alert('yes')
// }else{
//     alert('No')
// }


     //Q9

// let dog = 'snickers'
// logdog(dog);
// function logdog(dog){
//     console.log(dog);
// }
// function go(){
//     let dog = 'sunny';
//     logdog(dog)
//  }
// go();


       //Q.10

// let text =`He's often called "Johnny"`;
// console.log(text);


          //Q.11


// function welcome(name = 'Everyone'){
//     let msg = 'Welcome' + " " + name;
//     console.log(msg);
// }
// welcome('Misbah')
// welcome()


           //Q.12

// var myPromise = true;      
// let count = new Promise((resolve) => {         
// if (setTimeout(resolve, 5000) === myPromise){
//         resolve('yahooo')
// }
   
// });

// count
// .then(res => console.log(res))
